package com.corsospring.error;

public class GlobalExceptionHandler {

}

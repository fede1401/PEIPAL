package com.corsospring.restcontroller;

public class UtenteRestController {

}

package com.corsospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeipalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeipalApplication.class, args);
	}

}

package com.corsospring.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity
public class Amministratore extends Utente {
	
	private Integer livello;
	
	public Amministratore() {
	}

	public Amministratore(Integer livello) {
		super();
		this.livello = livello;
	}

	public Integer getLivello() {
		return livello;
	}

	public void setLivello(Integer livello) {
		this.livello = livello;
	}
	
	
	
	

}

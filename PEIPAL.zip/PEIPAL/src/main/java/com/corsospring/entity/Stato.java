package com.corsospring.entity;

public enum Stato {
	VALIDO,
	SOSPESO,
	ATTESA
}

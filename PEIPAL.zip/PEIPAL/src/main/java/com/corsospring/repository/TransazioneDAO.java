package com.corsospring.repository;

import com.corsospring.entity.Transazione;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransazioneDAO extends JpaRepository<Transazione, Long> {

	List<Transazione> findAllByOrderByTimestampDesc();
    
} 